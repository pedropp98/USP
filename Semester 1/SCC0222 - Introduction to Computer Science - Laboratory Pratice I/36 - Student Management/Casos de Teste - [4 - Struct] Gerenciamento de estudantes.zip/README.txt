Arquivo zip gerado em: 21/01/2021 16:39:09 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [4 - Struct] Gerenciamento de estudantes