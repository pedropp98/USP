Arquivo zip gerado em: 11/10/2020 01:31:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Matriz] Estado do Jogo da Velha