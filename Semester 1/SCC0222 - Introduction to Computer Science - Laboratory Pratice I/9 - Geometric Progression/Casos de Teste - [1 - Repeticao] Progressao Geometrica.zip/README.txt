Arquivo zip gerado em: 11/10/2020 01:27:50 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [1 - Repetição] Progressão Geométrica