Arquivo zip gerado em: 11/10/2020 01:35:50 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Strings] Lidando com strings