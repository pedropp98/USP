Arquivo zip gerado em: 21/01/2021 16:33:43 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [3 - Funções/String] Particionamento de string