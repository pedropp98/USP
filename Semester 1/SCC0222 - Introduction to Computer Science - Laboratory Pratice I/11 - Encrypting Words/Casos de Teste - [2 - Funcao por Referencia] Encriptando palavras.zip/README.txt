Arquivo zip gerado em: 11/10/2020 01:30:07 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Função por Referência] Encriptando palavras